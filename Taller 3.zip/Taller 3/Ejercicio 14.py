#Crear una matriz A ∈ R 10×10 y multiplicar por una matriz B ∈ R 10×2.
import numpy as np
#from numpy import random
A = np.random.randint(20, size = (10,10))
D = np.random.randint(20, size =(10,2) )
print(A)
print(D)
#Multiplicación:
print(np.dot(A,D))

