#Crear una matriz concatenando diez vectores de longitud 5 utilizando la
#funcion de numpy vstack. Mostrar un mensaje con el numero de filas y
#columnas de la matriz.
import numpy as np

v_1 = np.array([1,2,3,4,5])
v_2 = np.array([2,0,2,0,2])
v_3 = np.array([1,0,4,0,5])
v_4 = np.array([5,6,5,8,9])
v_5 = np.array([1,6,7,4,2])
v_6 = np.array([1,7,3,4,5])
v_7 = np.array([6,5,3,3,5])
v_8 = np.array([6,2,3,4,5])
v_9 = np.array([1,4,3,4,4])
v_10 = np.array([4,7,3,4,3])

M_f = np.vstack((v_1,v_2,v_3,v_4,v_5,v_6,v_7,v_8,v_9,v_10))
print(M_f)
print(f"Las dimensiones de la matriz M_f es:", np.shape(M_f))

#otra:

print(f"El numero de columnas es: {len(M_f[0])}, y el numero de filas es: {len(M_f)} ")