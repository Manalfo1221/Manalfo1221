#En el vector resultante del ejercicio 9, reemplazar los valores no asignados
#por el promedio de los demas valores.

from statistics import mean
import numpy as np
z = np.random.normal(0, 1, 100)
cp = z.copy()
cp[np.arange(0,100,10)] = np.nan
p = cp[np.logical_not(np.isnan(cp))]
m = mean(p)
cp[np.arange(0,100,10)] = m
print(cp)
print(m)
#print(len(cp))
