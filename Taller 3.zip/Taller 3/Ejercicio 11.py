#EJERCICIOS 6
#Generar 10000 numeros aleatorios muestreados de una distribucion normal
#bimodal con µ1 = −5, σ1 = 1, µ2 = 3, y σ1 = 0.5. Mostrar el histograma.
import numpy as np
import matplotlib.pyplot as plt
z = np.random.normal(-5,1,5000 )
v = np.random.normal(3, 0.5, 5000 )
zv = np.concatenate((z,v), axis=0)
print(len(zv))
plt.hist(zv)
plt.show()



