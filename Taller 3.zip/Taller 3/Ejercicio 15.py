#Calcular la inversa de la matriz A ∈ R 10×10
import numpy as np
A = np.random.randint(20, size = (10,10))
inver = np.linalg.inv(A)
i = np.dot(A,inver)
print(np.round(i))