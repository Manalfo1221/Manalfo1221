#Crear un data frame con tres columnas: normal_1, normal_2 y bimodal
#y 1000 filas. normal_1 contiene valores aleatorios tomados de una distribucion
#normal µ1 = −10, σ1 = 2,
#normal_2 contiene valores aleatorios
#tomados de una distribucion normal µ2 = 10, σ2 = 2, y bimodal contiene valores aleatorios
# tomados de una distribucion bimodal que combina
#normal_1 y normal_2.
import pandas as pd
import numpy as np
from numpy import random

x = np.random.normal(-10,2,500)
y = np.random.normal(10,2,500)
z = np.concatenate((x,y))

d = {'normal_1' : np.random.normal(-10,2,1000),
     'normal_2' : np.random.normal(10,2,1000),
     'bimodal' : z }

mi_df = pd.DataFrame(data = d)

print(mi_df)
print(len(mi_df))