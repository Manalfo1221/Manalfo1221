#Calcular el maximo y mınimo de los valores de un vector sin utilizar las
#funciones max y min de Python.
import numpy as np

x =  np.array([1,2,3,4,5])
for i in x:
    maxm = x[0]
    if i > maxm:
        maxm = i

for i in x:
    minm = x[0]
    if i < minm:
        minm = i

print(f'máximo:{maxm}')
print(f'mínimo:{minm}')