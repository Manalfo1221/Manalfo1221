#. Crear el siguiente data frame y luego ejecutar la lınea df.apply(np.sqrt)
#¿Que sucede?
import numpy as np
import pandas as pd
df = pd.DataFrame([[4, 9]] * 3,
                  columns = ["A", "B"])
print(df)
print(df.apply(np.sqrt))

#La linea df.apply(np.sqrt) saca la raiz cuadrada a los valores del DataFrame (df).