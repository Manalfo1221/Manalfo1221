#Generar un vector de dimensión 100 con valores aleatorios de distribución
#normal estándar.
import numpy as np
z = np.random.normal(0,1,100)
print(z)