#Ejercicio 5
#Grupo:
#Manuel Alfonso Rodríguez Ariño
#Cristian David Padilla Peinado
#Triana Nicols Ramirez Fernandez

#1.Mostrar en pantalla la frase ‘¡Hola mundo!’ o ‘Hello world!’
print("Hola Mundo")