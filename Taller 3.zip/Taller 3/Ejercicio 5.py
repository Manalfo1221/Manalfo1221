#Calcular el máximo y mínimo de los valores de un vector.
import numpy as np
j = np.array([2,4,6,8,10])
print(min(j))
print(max(j))