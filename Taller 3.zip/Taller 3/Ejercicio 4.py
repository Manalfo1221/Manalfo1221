#Calcular el promedio de los valores de un vector. Mostrar en pantalla la
#frase “El promedio es ...”
import numpy as np
y = np.array([5,6,3,4,3])
pro = sum(y)/5
print(f"El promedio es: {pro}")