#Crear una matriz concatenando diez vectores de longitud 5 utilizando la
#funcion de numpy hstack. Mostrar un mensaje con el numero de filas y
#columnas de la matriz.
import numpy as np
from numpy import hstack
v1 = np.array([[12],[13],[14],[15],[16]])
v2 = np.array([[1],[2],[3],[4],[5]])
v3 = np.array([[20],[21],[22],[23],[24]])
v4 = np.array([[10],[9],[8],[7],[6]])
v5 = np.array([[13],[14],[15],[16],[17]])

M = np.hstack((v1,v2,v3,v4,v5))
print(M)
print(f"El numero de columnas de la matriz M es: {len(M)}, "
      f"y el numero de filas es: {len(M[0])}")

#OTRA FORMA ES
print(f"Las dimensiones de la matriz M es:", np.shape(M))
