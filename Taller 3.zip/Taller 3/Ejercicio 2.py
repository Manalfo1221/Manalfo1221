#Calcular el promedio de dos números.
a = 20
b = 45
print(a,b)
prom = (a+b)/2
print(f'El promedio de {a} y {b} es: {prom}')


