#Remover los valores del vector del ejercicio anterior cuyo valor absoluto
#sea ≥ 1.
import numpy as np
z = np.random.normal(0,1,100)

z_abs = np.abs(z)
z_f = z[z_abs>1]
#z2 = z[z_abs<1]
print(z_f)
#print(z2)