#Reemplazar 10 de los valores del vector del ejercicio 7, escogidos aleatoriamente,
# por un sımbolo de Python que represente valores no asignados.

import numpy as np

z = np.random.normal(0, 1, 100)
cp = z.copy()
cp[np.arange(0,100,10)] = np.nan
print(cp)
#print(z)

