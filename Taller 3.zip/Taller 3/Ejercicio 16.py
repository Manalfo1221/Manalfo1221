#Crear el siguiente data frame y despues de creado agregar la columna
#"numero" = [1.2, 3.4, 4.5, 5.6]:

import pandas as pd

mi_df = pd.DataFrame(data={"entero": range(1,5),
                           "factor": ["a", "b", "c", "d"],
                           "cadena": ["a", "b", "c", "d"]
})

df_new = mi_df.assign( numero = [1.3,3.4,4.5,5.6])

print(mi_df)
print(df_new)
