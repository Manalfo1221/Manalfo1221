#Mostrar en pantalla el vector [1, 2, 3, 4, 5]
import numpy as np
x = np.array([1,2,3,4,5])
print(x)

y = [1,2,3,4,5]
print(y)